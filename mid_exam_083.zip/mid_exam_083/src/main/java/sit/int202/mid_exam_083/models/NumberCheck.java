package sit.int202.mid_exam_083.models;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class NumberCheck {
    private int number;
    private boolean isPrime;
}
